<?php require $_SERVER['DOCUMENT_ROOT'].'/bitrix/header.php';

	\$APPLICATION->SetTitle('Новая страница');
	\$APPLICATION->SetPageProperty('title', '');
	\$APPLICATION->SetPageProperty('description', '');

?>

<?require $_SERVER['DOCUMENT_ROOT'].'/bitrix/footer.php'?>