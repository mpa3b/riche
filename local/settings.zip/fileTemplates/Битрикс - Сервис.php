<?php require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include.php';

	CModule::IncludeModule('iblock');